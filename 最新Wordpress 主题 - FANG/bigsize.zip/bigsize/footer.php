	<a id="gotop" href="#" target="_self" style="bottom: -100px;"></a>
	<div id="footer-widgets">
		<div class="v-clearfix" id="footer-widgets-wrapper">
			<?php dynamic_sidebar('Footer') ?>
		</div>
	</div>
	<div class="footer">
		<div class="section">
			<p>Powered by WordPress, Theme <a href="http://moooc.cc/archives/783" target="_blank">bigsize</a>.</p>
			<p><?php echo get_option('mooc_copyright')?></p>
		</div>
	</div>
<?php wp_footer(); ?>
</body>
</html>