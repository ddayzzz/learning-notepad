<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>	
<div class="article-banner v-clearfix" style="background-image:url('<?php echo mooc_thumbnail_url();?>')">
		<h1 class="article-title"><?php the_title();?></h1>
		<div class="postMeta"><?php the_author(); ?>发布于<?php echo get_the_date('Y年n月j日');?> - <?php echo get_the_category_list(" ");?>分类 - <?php if ( function_exists('get_the_views') ) echo get_the_views($post->ID); ?>次阅读 - <?php echo get_post($post->ID)->comment_count?>条评论<?php edit_post_link('编辑',' - '); ?></div>
</div>
<div class="container v-clearfix">
	<div class="posts">
			<div class="article-content">
				<?php 
				$s = get_the_content();
				if (strncmp($s,'<img ',5) == 0)
					print preg_replace('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', '', apply_filters('the_content', $s), 1);
				else
					print apply_filters('the_content', $s);
				?>
			</div>
			<?php reward_button(); comments_template( '', true ); ?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php endwhile; ?>
<?php get_footer(); ?>