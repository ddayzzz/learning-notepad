<?php get_header(); ?>
<div class="container v-clearfix">
	<div>
		<h2>没有找到你要的内容！</h2>
		<p><a href="<?php echo home_url(); ?>">返回首页</a></p>
	</div>
</div>
<?php get_footer(); ?>