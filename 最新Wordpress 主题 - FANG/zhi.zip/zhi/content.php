<article class="post">
	<div class="block-content v-clearfix">
		<a class="feature-img" href="<?php the_permalink();?>">
			<?php mooc_thumbnail();?>
		</a>
		<div class="summary">
			<h2 class="article-title">
				<a title="<?php the_title();?>" href="<?php the_permalink();?>"><?php the_title();?></a>
			</h2>
			<div class="article-summary">
				<p><?php echo mb_strimwidth(strip_tags($post->post_content), 0, 260,"...");?></p>
			</div>
		</div>
	</div>
	<div class="postMeta">
		<p><?php echo get_the_date('Y年n月j日');?> - <?php if ( function_exists('get_the_views') ) echo get_the_views($post->ID); ?>次阅读 - <?php echo get_post($post->ID)->comment_count?>条评论<?php edit_post_link('编辑',' - '); ?>
</p>
	</div>
</article>